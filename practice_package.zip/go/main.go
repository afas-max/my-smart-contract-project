package main

import (
    "context"
    "database/sql"
    "encoding/json"
    "fmt"
    "log"
    "math/big"
    "os"
    "os/signal"
    "sync"
    "syscall"
    "time"

    _ "github.com/lib/pq"
    "github.com/robfig/cron/v3"
    "github.com/ethereum/go-ethereum"
    "github.com/ethereum/go-ethereum/common"
    "github.com/ethereum/go-ethereum/ethclient"
)

type ChainConfig struct {
    Name          string `json:"name"`
    RPC           string `json:"rpc"`
    ConfirmBlocks int64  `json:"confirm_blocks"`
    StartBlock    int64  `json:"start_block"`
    TokenAddress  string `json:"token_address"`
}

type Config struct {
    PostgresDSN string        `json:"postgres_dsn"`
    Chains      []ChainConfig `json:"chains"`
}

var transferSig = common.HexToHash("0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef")

func main() {
    cfgBytes, err := os.ReadFile("config.json")
    if err != nil {
        log.Fatal("read config.json:", err)
    }
    var cfg Config
    if err := json.Unmarshal(cfgBytes, &cfg); err != nil {
        log.Fatal(err)
    }

    db, err := sql.Open("postgres", cfg.PostgresDSN)
    if err != nil {
        log.Fatal(err)
    }
    defer db.Close()

    ctx, cancel := context.WithCancel(context.Background())
    var wg sync.WaitGroup
    for _, ch := range cfg.Chains {
        wg.Add(1)
        go func(c ChainConfig) {
            defer wg.Done()
            runIndexer(ctx, db, c)
        }(ch)
    }

    // hourly cron (run at 0th minute)
    c := cron.New(cron.WithLocation(time.UTC))
    _, err = c.AddFunc("0 0 * * * *", func() {
        now := time.Now().UTC()
        t0 := now.Add(-1 * time.Hour)
        for _, ch := range cfg.Chains {
            if err := computePointsForInterval(db, ch.Name, t0, now); err != nil {
                log.Printf("compute points %s err: %v", ch.Name, err)
            }
        }
    })
    if err != nil {
        log.Fatal(err)
    }
    c.Start()

    stop := make(chan os.Signal, 1)
    signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)
    <-stop
    cancel()
    c.Stop()
    wg.Wait()
    log.Println("shutdown")
}

func runIndexer(ctx context.Context, db *sql.DB, cfg ChainConfig) {
    client, err := ethclient.DialContext(ctx, cfg.RPC)
    if err != nil {
        log.Printf("[%s] dial err: %v", cfg.Name, err)
        return
    }
    defer client.Close()

    last := cfg.StartBlock
    ticker := time.NewTicker(5 * time.Second)
    defer ticker.Stop()
    for {
        select {
        case <-ctx.Done():
            return
        case <-ticker.C:
            header, err := client.HeaderByNumber(ctx, nil)
            if err != nil {
                log.Printf("[%s] head err: %v", cfg.Name, err)
                continue
            }
            head := header.Number.Int64()
            safeHead := head - cfg.ConfirmBlocks
            if safeHead <= last {
                continue
            }
            to := safeHead
            if to-last > 100 {
                to = last + 100
            }
            token := common.HexToAddress(cfg.TokenAddress)
            q := ethereum.FilterQuery{
                FromBlock: big.NewInt(last+1),
                ToBlock:   big.NewInt(to),
                Addresses: []common.Address{token},
                Topics:    [][]common.Hash{{transferSig}},
            }
            logs, err := client.FilterLogs(ctx, q)
            if err != nil {
                log.Printf("[%s] filter logs err: %v", cfg.Name, err)
                continue
            }
            for _, lg := range logs {
                if lg.Topics[0] != transferSig {
                    continue
                }
                from := common.HexToAddress(lg.Topics[1].Hex())
                to := common.HexToAddress(lg.Topics[2].Hex())
                amt := new(big.Int).SetBytes(lg.Data)
                // get block time (best-effort)
                blk, err := client.BlockByNumber(ctx, big.NewInt(int64(lg.BlockNumber)))
                var ts time.Time
                if err == nil {
                    ts = time.Unix(int64(blk.Header().Time), 0)
                } else {
                    ts = time.Now().UTC()
                }
                if err := processTransfer(db, cfg.Name, lg.BlockNumber, lg.TxHash.Hex(), int(lg.Index), from.Hex(), to.Hex(), amt, ts); err != nil {
                    log.Printf("processTransfer err: %v", err)
                }
            }
            last = to
        }
    }
}

func processTransfer(db *sql.DB, chain string, blockNumber uint64, txHash string, logIndex int, from, to string, amount *big.Int, eventTime time.Time) error {
    tx, err := db.Begin()
    if err != nil { return err }
    defer tx.Rollback()

    zero := "0x0000000000000000000000000000000000000000"
    if from != zero {
        if err := applyDelta(tx, chain, from, new(big.Int).Neg(amount), blockNumber, txHash, logIndex, eventTime); err != nil {
            return err
        }
    }
    if to != zero {
        if err := applyDelta(tx, chain, to, amount, blockNumber, txHash, logIndex, eventTime); err != nil {
            return err
        }
    }
    return tx.Commit()
}

func applyDelta(tx *sql.Tx, chain, user string, delta *big.Int, blockNumber uint64, txHash string, logIndex int, eventTime time.Time) error {
    // read current balance
    var cur string
    err := tx.QueryRow("SELECT balance FROM user_balances WHERE chain=$1 AND user_address=$2 FOR UPDATE", chain, user).Scan(&cur)
    if err != nil && err != sql.ErrNoRows { return err }
    curBal := new(big.Int)
    if err == sql.ErrNoRows {
        curBal.SetInt64(0)
        _, err = tx.Exec("INSERT INTO user_balances (chain, user_address, balance, updated_at) VALUES ($1,$2,$3,now()) ON CONFLICT DO NOTHING", chain, user, "0")
        if err != nil { return err }
    } else {
        curBal.SetString(cur, 10)
    }
    newBal := new(big.Int).Add(curBal, delta)
    if newBal.Sign() < 0 {
        newBal.SetInt64(0)
    }
    _, err = tx.Exec("INSERT INTO balance_changes (chain, user_address, delta, new_balance, block_number, tx_hash, log_index, event_time) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT DO NOTHING", chain, user, delta.String(), newBal.String(), int64(blockNumber), txHash, logIndex, eventTime)
    if err != nil { return err }
    _, err = tx.Exec("UPDATE user_balances SET balance=$1, updated_at=now() WHERE chain=$2 AND user_address=$3", newBal.String(), chain, user)
    return err
}

// computePointsForInterval uses decimal approximations (for production use high-precision decimal lib)
func computePointsForInterval(db *sql.DB, chain string, t0, t1 time.Time) error {
    rows, err := db.Query("SELECT DISTINCT user_address FROM balance_changes WHERE chain=$1 AND (event_time >= $2 AND event_time < $3) OR event_time < $2", chain, t0, t1)
    if err != nil { return err }
    defer rows.Close()
    var users []string
    for rows.Next() {
        var u string
        rows.Scan(&u)
        users = append(users, u)
    }
    rate := 0.05
    for _, u := range users {
        // last balance before t0
        var lastBal sql.NullString
        var lastTime sql.NullTime
        err := db.QueryRow("SELECT new_balance, event_time FROM balance_changes WHERE chain=$1 AND user_address=$2 AND event_time < $3 ORDER BY event_time DESC LIMIT 1", chain, u, t0).Scan(&lastBal, &lastTime)
        curBal := big.NewInt(0)
        if err == nil && lastBal.Valid {
            curBal.SetString(lastBal.String, 10)
        } // else keep 0

        evRows, err := db.Query("SELECT event_time, new_balance FROM balance_changes WHERE chain=$1 AND user_address=$2 AND event_time >= $3 AND event_time < $4 ORDER BY event_time ASC", chain, u, t0, t1)
        if err != nil { return err }
        segStart := t0
        currentFloat := bigIntToFloat64(curBal)
        accum := 0.0
        for evRows.Next() {
            var et time.Time
            var nb string
            evRows.Scan(&et, &nb)
            duration := et.Sub(segStart).Seconds()
            accum += currentFloat * rate * (duration / 3600.0)
            nbInt := new(big.Int)
            nbInt.SetString(nb, 10)
            currentFloat = bigIntToFloat64(nbInt)
            segStart = et
        }
        evRows.Close()
        // final
        duration := t1.Sub(segStart).Seconds()
        if duration > 0 {
            accum += currentFloat * rate * (duration / 3600.0)
        }
        // persist
        _, err = db.Exec("INSERT INTO user_points (chain, user_address, total_points, updated_at) VALUES ($1,$2,$3,now()) ON CONFLICT (chain,user_address) DO UPDATE SET total_points = (user_points.total_points::numeric + $3::numeric)::text, updated_at = now()", chain, u, fmt.Sprintf("%.18f", accum))
        if err != nil { return err }
    }
    return nil
}

func bigIntToFloat64(i *big.Int) float64 {
    f, _ := new(big.Float).SetInt(i).Float64()
    return f
}
