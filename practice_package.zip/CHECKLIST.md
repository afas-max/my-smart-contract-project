# Strict Task Checklist (mapping to files)

Original user task list:
1. Deploy an ERC20 with mint and burn, mint/burn/transfer several tokens to generate events.
   - Implemented: contracts/SimpleToken.sol
   - Hardhat scripts: hardhat/scripts/deploy.js, hardhat/scripts/actions.js
2. Use Go backend to track contract events and rebuild user balances.
   - Implemented: go/main.go (runIndexer + processTransfer + applyDelta)
3. Delay by six blocks (confirmations) to ensure chain won't roll back.
   - Implemented: config.json `confirm_blocks`: 6 and used in go/main.go indexing logic
4. Add points computation: hourly job computing points = balance * 0.05.
   - Implemented: go/main.go cron job and computePointsForInterval function
5. Record all balance changes and compute points from those records.
   - Implemented: db/migrations/001_init.sql -> balance_changes table
   - applyDelta inserts balance_changes
6. Maintain user total balance table and total points table, and a balance-change record table.
   - Implemented: user_balances, user_points, balance_changes in migrations
7. Support multi-chain logic (example: sepolia, base sepolia).
   - Implemented: config.json sample and go/indexer supports multiple chain configs.

Notes:
- The point computation currently uses float math for clarity. For production use, replace with a high-precision decimal library (eg. shopspring/decimal) and store points as numeric/text.
- Ensure to set up environment variables for Hardhat (SEPOLIA_RPC, PRIVATE_KEY, TOKEN_ADDRESS) before running scripts.
- The Hardhat actions.js includes a burn call; because burn(address,uint256) is owner-only in the contract, the owner can call burn to reduce any user's balance (this matches the earlier design). If you prefer burnFrom semantics, extend the contract accordingly.

Files to review:
- contracts/SimpleToken.sol
- hardhat/*.js
- db/migrations/001_init.sql
- go/main.go
- config.json
