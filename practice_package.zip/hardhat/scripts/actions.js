const { ethers } = require("hardhat");

async function main() {
  const [owner, a, b] = await ethers.getSigners();
  const deployed = process.env.TOKEN_ADDRESS;
  if (!deployed) {
    console.error("Please set TOKEN_ADDRESS env var");
    return;
  }
  const token = await ethers.getContractAt("SimpleToken", deployed);

  console.log("Mint 100 tokens to A:", a.address);
  await token.mint(a.address, ethers.utils.parseUnits("100", 18));
  console.log("Transfer 20 from A -> B");
  await token.connect(a).transfer(b.address, ethers.utils.parseUnits("20", 18));
  console.log("B approves owner to burn 10, then owner burns 10 from B");
  await token.connect(b).approve(owner.address, ethers.utils.parseUnits("10", 18));
  // To burn from B using owner, B must have given allowance and contract must implement burnFrom.
  // Our SimpleToken has only burn(address,uint256) restricted to owner.
  // For demo: owner will call burn on B (owner must hold permission in this SimpleToken implementation).
  await token.burn(b.address, ethers.utils.parseUnits("10", 18));
  console.log("Actions done.");
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
