# Practice Package - ERC20 Event Indexer + Points Calculation

This package implements the full practice task:
1) Deploy an ERC20 with mint & burn, generate events.
2) Go backend to track events, rebuild balances.
3) Use 6-block confirmation to avoid reorgs.
4) Hourly job to compute points = balance * 0.05 (pro-rated by time).
5) Persist all balance changes for accurate point computation.
6) Maintain user_balances, user_points, balance_changes tables.
7) Multi-chain support (example: sepolia, base_sepolia).

## Structure
- contracts/: Solidity contract
- hardhat/: hardhat config and scripts
- db/migrations/: SQL migrations
- go/: Go indexer backend
- config.json: sample config
- README.md: this file
- CHECKLIST.md: strict task checklist and mapping to files

## Quickstart (local)
1. Set up Postgres and run `db/migrations/001_init.sql`.
2. Configure `config.json` and `.env` for Hardhat.
3. Deploy contract with Hardhat, set token address in config.json.
4. Build & run Go backend: `cd go && go run main.go`
