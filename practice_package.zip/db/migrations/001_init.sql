-- Database schema for balances, points and balance change records
CREATE TABLE IF NOT EXISTS user_balances (
  chain VARCHAR NOT NULL,
  user_address TEXT NOT NULL,
  balance TEXT NOT NULL DEFAULT '0',
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  PRIMARY KEY (chain, user_address)
);

CREATE TABLE IF NOT EXISTS user_points (
  chain VARCHAR NOT NULL,
  user_address TEXT NOT NULL,
  total_points TEXT NOT NULL DEFAULT '0',
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  PRIMARY KEY (chain, user_address)
);

CREATE TABLE IF NOT EXISTS balance_changes (
  id BIGSERIAL PRIMARY KEY,
  chain VARCHAR NOT NULL,
  user_address TEXT NOT NULL,
  delta TEXT NOT NULL,
  new_balance TEXT NOT NULL,
  block_number BIGINT NOT NULL,
  tx_hash TEXT NOT NULL,
  log_index INT NOT NULL,
  event_time TIMESTAMP WITH TIME ZONE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- unique constraint to avoid duplicate processing
CREATE UNIQUE INDEX IF NOT EXISTS uc_chain_tx_log ON balance_changes (chain, tx_hash, log_index);

CREATE TABLE IF NOT EXISTS point_run_state (
  id SERIAL PRIMARY KEY,
  chain VARCHAR NOT NULL,
  last_run TIMESTAMP WITH TIME ZONE NOT NULL
);
